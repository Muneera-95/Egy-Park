package com.proga.egy_park

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
